<?php

session_start();

function combatling(){
    echo '<img src="images\arup.png">';
}

