<?php

session_start();

function moveUp(){
    
if($_SESSION['up']){
    $_SESSION['marioPosition'] = $_SESSION['marioPosition'] - 8;
    $_SESSION['marioSpriteY'] =  $_SESSION['marioSpriteY'] + 1;
}
}

moveUp();
header('Location: index.php');