<?php
session_start();
// session_destroy();
require_once("Combatant.php");
require_once("ItemHandler.php");
require_once("script_driver_DB.php");
require_once("index_functions.php");


if (!isset($_SESSION["gameStart"])) {
  $_SESSION['items'] = serialize(new ItemHandler(1, 1));
  $_SESSION['protagonist'] = serialize(new Combatant(50, 15, 8, "Mario", "combat_sprite_ready.png"));
  $_SESSION["gameStart"] = 1;
  $_SESSION['marioPosition'] = 1;
  $_SESSION['marioSpriteX'] = 0;
  $_SESSION['marioSpriteY'] = 7;
  $_SESSION['map'] = 1;
  $_SESSION['hasKey'] = 0;
}


$DB = new DB();
$DB->connect();
$sql = "SELECT * FROM map_data WHERE map =" . $_SESSION['map'] . " ORDER BY map_identifier ASC";
$_SESSION['map_data'] = $DB->getQuery($sql);


// echo "(".$_SESSION['marioSpriteX'].",".$_SESSION['marioSpriteY'].")";

?>
<style>
  @font-face {
    font-family: "super_mario_256regular";
    src: url("supermario256.woff2") format("woff2"),
      url("supermario256.woff") format("woff");
    font-weight: normal;
    font-style: normal;
  }

  body {
    background-image: url('bg_main.png');
    background-color: #cccccc;
    background-repeat: none;
  }

  table {
    border-collapse: collapse;
  }

  /* And this to your table's `td` elements. */
  td {
    padding: 0;
    margin: 0;
  }

  #map {
    margin: 0;
    padding: 0;
    position: absolute;
    background-color: #fe9800;
    width: 640px;
    height: 640px;
    left: 64px;
    top: 66px
  }

  #logs {
    font-family: "super_mario_256regular", Arial, sans-serif;
    margin: 0;
    padding: 10;
    position: absolute;
    width: 505px;
    height: 354px;
    left: 780px;
    top: 48px;
    overflow: auto;
    scrollbar-color: orange lightyellow;
  }

  .mapTile {
    margin: 0;
  }


  #status-hp {
    font-family: "super_mario_256regular", Arial, sans-serif;
    position: absolute;
    top: 477px;
    left: 830px;
    font-size: 32px;
  }

  #controls {
    display: flex;
    position: absolute;
    padding: 0;
    margin: 0;
    height: auto;
    width: 560px;
    top: 560px;
    left: 780px;
    font-size: 32px;
  }

  #status-potion {
    font-family: "super_mario_256regular", Arial, sans-serif;
    position: absolute;
    top: 477px;
    left: 1020px;
    font-size: 32px;
  }

  #status-bomb {
    font-family: "super_mario_256regular", Arial, sans-serif;
    position: absolute;
    top: 477px;
    left: 1220px;
    font-size: 32px;
  }
</style>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Super Mario and The Sand That Got Away</title>
</head>

<body>
  <div id="map">
    <?php
    sprite($_SESSION['marioSpriteX'], $_SESSION['marioSpriteY'], "sprite_mario.png", "mario", 3);
    generate_map();
    ?>
  </div>
  <div id="status-hp"><?php echo unserialize($_SESSION['protagonist'])->getstats()["hp"] ?></div>
  <div id="status-potion"><?php echo unserialize($_SESSION['items'])->getItems()['potions'] ?>/3</div>
  <div id="status-bomb"><?php echo unserialize($_SESSION['items'])->getItems()['bombs'] ?>/3</div>
  <div id="controls">



    <?php
    encounterDetection($_SESSION['marioPosition']);
    enterNextMap($_SESSION['marioPosition']);
    collisionDetection($_SESSION['marioPosition']);
    if ($_SESSION['left'] == false) {
      echo '<a href="#"><img src="controls_left.png" opacity:0.5></a>';
    } else
      echo '<a href="script_action_moveLeft.php" onClick= moveLeft()><img src="controls_left.png"></a>';

    if ($_SESSION['up'] == false) {
      echo '<a href="#"><img src="controls_up.png" opacity:0.5></a>';
    } else
      echo '<a href="script_action_moveUp.php" onClick= moveUp()><img src="controls_up.png"></a>';


    echo '<a href="http://"><img src="controls_key.png"></a>';

    if ($_SESSION['down'] == false) {
      echo '<a href="#"><img src="controls_down.png" opacity:0.5></a>';
    } else
      echo '<a href="script_action_moveDown.php  " onClick= moveDown()><img src="controls_down.png"></a>';


    if ($_SESSION['right'] == false) {
      echo '<a href="#"><img src="controls_right.png" opacity:0.5></a>';
    } else
      echo '<a href="script_action_moveRight.php  " onClick= moveRight()><img src="controls_right.png"></a>';

    ?>

    <script>
      window.onkeydown = function(event) {
        // up 38
        // left 37
        // down 40
        // right 39
        if (event.keyCode == 37) {
          window.location.href = "script_action_moveLeft.php";
        }
        if (event.keyCode == 38) {
          window.location.href = "script_action_moveUp.php";
        }
        if (event.keyCode == 39) {
          window.location.href = "script_action_moveRight.php";
        }
        if (event.keyCode == 40) {
          window.location.href = "script_action_moveDown.php";
        }
      }
    </script>

  </div>
  <div id="logs">
    <div id="log-item">
      <?php
      echo ($_SESSION['proceed']);
      echo '</br>';
      echo ($_SESSION['encounter']);
      echo '</br>';
      echo ($_SESSION['marioPosition']);
      collissionDetectionPrinting();
      logs();
      ?>
    </div>
  </div>
</body>

</html>