<?php

session_start();

function moveRight(){
    if($_SESSION['right']){
    $_SESSION['marioPosition'] = $_SESSION['marioPosition'] + 1;
    $_SESSION['marioSpriteX'] =  $_SESSION['marioSpriteX'] + 1;
    }
}

moveRight();
header('Location: index.php');