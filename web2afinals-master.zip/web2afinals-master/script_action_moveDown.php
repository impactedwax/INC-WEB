<?php

session_start();

function moveDown(){
    if($_SESSION['down']){
    $_SESSION['marioPosition'] = $_SESSION['marioPosition'] + 8 ;
    $_SESSION['marioSpriteY'] =  $_SESSION['marioSpriteY'] - 1;
    }
}

moveDown();
header('Location: index.php');