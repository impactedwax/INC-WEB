<?php
session_start();
require_once("ItemHandler.php");
require_once("combat_screen_functions.php");
require_once("Logs.php");

$log_handler = new LogsCombat();

require("Combatant.php");

if (!isset($_SESSION['enemies'])) {
    $_SESSION['enemies'] = getEnemiesFromDB();
}
if (!isset($_SESSION['combatStart'])) {
    $roll_mob = rand(0, 2);
    $_SESSION['antagonist'] = serialize(new Combatant(
        $_SESSION['enemies'][$roll_mob]['hp'],
        $_SESSION['enemies'][$roll_mob]['attack'],
        $_SESSION['enemies'][$roll_mob]['defense'],
        $_SESSION['enemies'][$roll_mob]['mobName'],
        $_SESSION['enemies'][$roll_mob]['image']
    ));
    $_SESSION['combatStart'] = true;
    $_SESSION['combatEnd'] = false;
    if (!isset($_SESSION['combat_session_id']))
        $_SESSION['combat_session_id'] = 1;
    else
        $_SESSION['combat_session_id'] += 1;

    $CombatLog = new LogsCombat;
    $CombatLog->send_log("COMBAT STARTS!", "Combat", "<System>", $_SESSION["combat_session_id"]);
}

$Mario = unserialize($_SESSION['protagonist']);
$Enemy = unserialize($_SESSION['antagonist']);
$Items = unserialize($_SESSION['items']);

//evaluate the combat functions here
if ($_SESSION['combatStart']) {
    $action = getAction();
    if ($action == "attack") {
        $Enemy->take_damage($Mario->attack());
        if (!$Enemy->deathStatus()) {
            $Mario->take_damage($Enemy->attack());
            if ($Mario->deathStatus())
                $_SESSION['combatEnd'] = true; //game ends, mario dies
        } else $_SESSION['combatEnd'] = true; //combat ends, mario wins
    }
    if ($action == "defend") {
        $Mario->defend($Enemy->attack());
        if ($Mario->deathStatus())
            $_SESSION['combatEnd'] = true; //game ends, mario dies
    }
    if ($action == "heal") {
        $Mario->heal($Enemy->attack());
        $Items->usePotion();
        if ($Mario->deathStatus())
            $_SESSION['combatEnd'] = true; //game ends, mario dies
    }
    if ($action == "bomb") {
        $Mario->bomb();
        $Items->useBomb();
        $Enemy->bombed();
        if (!$Enemy->deathStatus()) {
            $Mario->take_damage($Enemy->attack());
            if ($Mario->deathStatus())
                $_SESSION['combatEnd'] = true; //game ends, mario dies
        } else $_SESSION['combatEnd'] = true; //combat ends, mario wins
    }
    $_SESSION['antagonist'] = serialize($Enemy);
    $_SESSION['protagonist'] = serialize($Mario);
    $_SESSION['items'] = serialize($Items);
}




?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Combat</title>
    <link rel="stylesheet" href="combat_screen_css.css">
</head>

<body>
    <div id="map">
        <div id="combat-announcer">
            <div>MARIO</div>
            <div>VS</div>
            <div>
                <?php
                echo $Enemy->getStats()['name'];
                ?></div>
        </div>
        <img src="bg_combat.png">
    </div>
    <div id="status-hp"><?php echo $Mario->getstats()["hp"] ?></div>
    <div id="status-potion"><?php echo $Items->getItems()['potions'] ?>/3</div>
    <div id="status-bomb"><?php echo $Items->getItems()['bombs'] ?>/3</div>
    <div id="controls">
        <a href="http://localhost/web2afinals/combat_screen.php?action=attack"><img src="combat_attack.png"></a>
        <a href="http://localhost/web2afinals/combat_screen.php?action=defend"><img src="combat_defend.png"></a>
        <?php
        if ($Items->getItems()['potions'])
            echo  '<a href="http://localhost/web2afinals/combat_screen.php?action=heal"><img src="combat_heal.png"></a>';
        else echo '<a href="http://localhost/web2afinals/combat_screen.php"><img src="combat_heal.png"></a>';
        if ($Items->getItems()['bombs'])
            echo  '<a href="http://localhost/web2afinals/combat_screen.php?action=bomb"><img src="combat_bomb.png"></a>';
        else echo '<a href="http://localhost/web2afinals/combat_screen.php"><img src="combat_bomb.png"></a>';
        ?></div>
    <div id="logs">
        <?php
        $log_handler->get_logs($_SESSION["combat_session_id"]);
        ?>
    </div>
    </div>
    <div class="combatant protagonist">
        <?php
        $Mario->render();
        ?>
    </div>
    <div class="combatant antagonist">
        <?php
        $Enemy->render();
        ?>
    </div>
</body>

</html>