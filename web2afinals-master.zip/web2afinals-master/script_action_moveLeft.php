<?php

session_start();
function moveLeft(){
    if($_SESSION['left']){
    $_SESSION['marioPosition'] = $_SESSION['marioPosition'] - 1;
    $_SESSION['marioSpriteX'] =  $_SESSION['marioSpriteX'] - 1;
    }
}

moveLeft();
header('Location: index.php');